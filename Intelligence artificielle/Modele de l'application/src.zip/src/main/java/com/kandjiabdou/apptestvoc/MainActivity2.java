package com.kandjiabdou.apptestvoc;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.UUID;

public class MainActivity2 extends AppCompatActivity {

    private Button btVoc;
    private Button btPlayStop;
    private boolean enEnregistrement=false;
    private boolean enPlay=false;
    private TextView textEnregistre;
    private TextView textPlayStop;

    private long tempsRetardAppui=500;
    private long tempsDebutAppui;

    final int REQUEST_PMISSION_CODE=1000;

    private String pathSave;
    private MediaRecorder mediaRecorder;
    private MediaPlayer mediaPlayer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        if(!verifierPermission())  demanderPermission();
        btVoc = findViewById(R.id.btEnregistre);
        btVoc.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(verifierPermission()){
                    if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){
                        if(enEnregistrement){
                            // s'il est en enregistrement en deux temps je l'arrete
                            textEnregistre.setText(getString(R.string.enregistrer));
                            enEnregistrement = false;
                            arreterEnregistrement();
                            btVoc.setBackgroundResource(R.drawable.record);
                        }else {
                            // Demarrage de l'engregistrement en appui long en dans 500 ms
                            tempsDebutAppui = System.currentTimeMillis();
                            new Handler().postDelayed(new Runnable() {
                                public void run() { if(!enEnregistrement) {
                                    demarrerEnregistrement();
                                    enEnregistrement = true;
                                    textEnregistre.setText(getString(R.string.enregistrement));
                                    btVoc.setBackgroundResource(R.drawable.recording);
                                } }
                            },500);
                        }
                        return true;
                    }else if(motionEvent.getAction()==MotionEvent.ACTION_UP){

                        // (3) cas sont possibles apres avoir laché le bouton
                        // 1- Demarrage de l'engregistrement en deux temps
                        // 2- Arret de l'enregistrement en deux temps
                        // 3- Arret de l'enregistrement en en Appui long

                        if(!enEnregistrement && System.currentTimeMillis()-tempsDebutAppui<tempsRetardAppui){
                            // 1- Demarrage de l'engregistrement en deux temps
                            textEnregistre.setText(getString(R.string.arreter));
                            demarrerEnregistrement();
                            enEnregistrement=true;
                            btVoc.setBackgroundResource(R.drawable.stop);
                        }else if(enEnregistrement){
                            // s'il est en enregistrement en en appui long je l'arrete
                            textEnregistre.setText(getString(R.string.enregistrer));
                            enEnregistrement = false;
                            arreterEnregistrement();
                            btVoc.setBackgroundResource(R.drawable.record);
                        }
                        return true;
                    }
                }else{
                    demanderPermission();
                }
                return false;

            }
        });

        btPlayStop = findViewById(R.id.btPlayStop);
        btPlayStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(enPlay){
                    textPlayStop.setText(getString(R.string.jouer));
                    enPlay=false;
                    btPlayStop.setBackgroundResource(R.drawable.play);
                    arreterSon();
                } else {
                    textPlayStop.setText(getString(R.string.pause));
                    enPlay=true;
                    btPlayStop.setBackgroundResource(R.drawable.pause);
                    demarrerSon();
                }
            }
        });
        pathSave = getApplicationContext().getExternalFilesDir("/").getAbsolutePath()+"_enregistrement_audio.3gp";
        btPlayStop.setEnabled(false);
        textEnregistre=findViewById(R.id.textEnregistre);
        textPlayStop=findViewById(R.id.textPlayStop);

    }

    private void demanderPermission() {
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.RECORD_AUDIO},REQUEST_PMISSION_CODE);
    }

    private boolean verifierPermission(){
        int acces_stockage= ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int acces_audio= ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
        return  acces_stockage== PackageManager.PERMISSION_GRANTED && acces_audio== PackageManager.PERMISSION_GRANTED ;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_PMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "Acces autorise", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "Acces refusé", Toast.LENGTH_SHORT).show();
        }
    }

    private void demarrerEnregistrement() {
        //pathSave = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+ UUID.randomUUID().toString()+"_enregistrement_audio.3gp";
        //T-C : mediaRecorder.setDataSource(pathSave);

        pathSave = getApplicationContext().getExternalFilesDir("/").getAbsolutePath()+"_enregistrement_audio.3gp";
        setupMadiaRecord();
        btPlayStop.setEnabled(false);
        mediaPlayer = new MediaPlayer();
        try {
            mediaRecorder.prepare();
        }catch (Exception e){ }
        mediaRecorder.start();
    }

    private void arreterEnregistrement() {
        btPlayStop.setEnabled(true);
        if(mediaRecorder!=null){
            mediaRecorder.stop();
            mediaRecorder.release();
        }
        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(pathSave);
            mediaPlayer.prepare();
        } catch (IOException e) {
            Toast.makeText(this,"Error Media : "+e,Toast.LENGTH_SHORT).show();
        }

    }

    private void setupMadiaRecord() {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mediaRecorder.setOutputFile(pathSave);
    }

    private void arreterSon(){
        btVoc.setEnabled(true);
        try{
            if(mediaPlayer!=null && mediaPlayer.isPlaying()) mediaPlayer.stop();
        }catch (Exception e){
            Toast.makeText(this,"Error A: "+e,Toast.LENGTH_SHORT).show();
        }

    }

    private void demarrerSon() {
        btVoc.setEnabled(false);
        try{
            if(mediaPlayer!=null && !mediaPlayer.isPlaying()) mediaPlayer.start();
        }catch (Exception e){
            Toast.makeText(this,"Error D : "+e,Toast.LENGTH_SHORT).show();
        }

    }

}